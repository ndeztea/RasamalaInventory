<div class="jumbotron">
        <h2>Welcome</h2>
        <p>
            Aplikasi ini adalah Codeigniter CRUD Generator, yang dapat mempermudah membuat suatu aplikasi dengan Codeigniter
        </p>
        
</div>