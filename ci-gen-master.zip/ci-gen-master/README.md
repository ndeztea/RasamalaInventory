ci-gen
======

Codeigniter CRUD Code Generator With Bootstrap 3.1.1, parsley 2.0 validation, easy to use & Simple

Support Modules


Screenshoot :
![ScreenShot](https://raw.github.com/brainlabs/ci-gen/master/ss.png)
![ScreenShot](https://raw.github.com/brainlabs/ci-gen/master/ss2.png)



installation :
==============

run your browser : http://localhost/ci-gen/install,



Create Your Own APP :
=====================
After installation : <br/>
1. design your database first, e.g "table, field".<br/>
2. generate your database in phpmyadmin.<br/>
3. open url in your browser : http://localhost/ci-gen/<br/>


Bahasa Indonesia :
===================
setelah diinstall :<br/>
1. yang pertama adalah design terlebih dahulu database kamu seperti membuat tabel dan field2nya,<br/>
2. setelah selesai database yg di buat td lakukan generate database kamu di phpmyadmin. ingat! tabel kamu di buat di nama database pada saat instalasi  <br/>
3. setelah point nomor 2, buka lah url di browser kamu : http://localhost/ci-gen/<br/>
4. sekarang masuk ke menu "Builder" , setelah muncul, pilih tabel yg mana akan di generate, klu sdh tampil disebelah kanannya tinggal pilih menu yg ada, lalu klik tombol build<br/>
5. setelah selesai di build, lakukan refresh. nanti akan muncul di menu content yg kmu generate tadi<br/>
